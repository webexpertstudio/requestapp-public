<?php
header('Cache-Control: no-cache, must-revalidate');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Content-type: application/json');
header('Access-Control-Allow-Origin: *'); 

if(!isset($_GET["API"]) || $_GET["API"]!="108M05970r7d6u50lou187061Yws8G") {
	die("Denied!!");
}
require ("includes/functions.php");  
require ("includes/connection.php");  // Poziva kod za konekciju na bazu podataka.
	
if(isset($_GET["ACTION"]) && $_GET["ACTION"]=="HELLO") {
	$args = array(
		'REQUEST_ID' => FILTER_SANITIZE_STRING, 
		'CAMPAIGN_TID' => FILTER_SANITIZE_STRING, 
		'INFORMER_ID' => FILTER_SANITIZE_STRING, 
		'SESSION_KEY' => FILTER_SANITIZE_STRING, 
		'TITLE' => FILTER_SANITIZE_STRING,
		'URI' => FILTER_SANITIZE_STRING,
	);
	$get = filter_input_array(INPUT_GET, $args);

	if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
		$get["CLIENT_IP"] = $_SERVER['HTTP_CLIENT_IP'];
	} 
	elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
		$get["CLIENT_IP"] = $_SERVER['HTTP_X_FORWARDED_FOR'];
	} 
	else {
		$get["CLIENT_IP"] = $_SERVER['REMOTE_ADDR'];
	}

	$client_country = "";
	if(isset($get["CLIENT_IP"]) && filter_var($get["CLIENT_IP"], FILTER_VALIDATE_IP)) {
		$ip = ip2long($get["CLIENT_IP"]);
		if($ip) {
			$sql = "SELECT `country` FROM `tbl_ip_countries` 
					WHERE `ip_from`<=".$ip."
					AND `ip_to`>=".$ip."
					LIMIT 1";
			$query	= db_query($sql);
			list($client_country) = mysql_fetch_row($query);
		}
	}
	if($get["INFORMER_ID"] && $get["REQUEST_ID"] && $get["SESSION_KEY"]) {
		$sql = "INSERT INTO `tbl_feedbacks` SET 
				`request_id`='".input_db($get["REQUEST_ID"])."',
				`informer_id`='".input_db((int) $get["INFORMER_ID"])."',
				`client_ip`='".input_db($get["CLIENT_IP"])."',
				`client_country`='".input_db($client_country)."',
				`URI`='".input_db($get["URI"])."',
				`title`='".input_db($get["TITLE"])."',
				`campaign_tid`='".input_db($get["CAMPAIGN_TID"])."',
				`session_key`='".input_db($get["SESSION_KEY"])."',
				`inserted`=NOW(),
				`active_until`=NOW()";
		db_query($sql); 
		echo "ok";
		// echo "<br>".$sql; 
	}
}
elseif(isset($_GET["ACTION"]) && $_GET["ACTION"]=="HEY") {
	$args = array(
		'REQUEST_ID' => FILTER_SANITIZE_STRING, 
		'SESSION_KEY' => FILTER_SANITIZE_STRING,
		'INFORMER_ID' => FILTER_SANITIZE_STRING, 
	);
	$get = filter_input_array(INPUT_GET, $args);
	
	if($get["INFORMER_ID"] && $get["REQUEST_ID"] && $get["SESSION_KEY"]) {
		$sql = "UPDATE `tbl_feedbacks` SET 
					`active_until`=NOW()
				WHERE `request_id`='".input_db($get["REQUEST_ID"])."'
				AND `session_key`='".input_db($get["SESSION_KEY"])."'
				AND `informer_id`='".input_db($get["INFORMER_ID"])."'
				";
		db_query($sql); 
		echo "ok";
		// echo "<br>".$sql; 
	}
}
?>
