<?php
require ("includes/connection.php");  // Poziva kod za konekciju na bazu podataka.
$username = $_POST['username'];
$passwordentered = md5('$_POST["password"]');
$agent_email=$_POST['agent_email'];
$agent_status=$_POST['agent_status'];
$agent_name=$_POST['agent_name'];
$agent_phone=$_POST['agent_phone'];
$agent_picture=$_POST['agent_picture'];

    $hash = hash('sha256', $password1);
     
    function createSalt()
    {
    $text = md5(uniqid(rand(), true));
    return substr($text, 0, 3);
    }
     
    $salt = createSalt();
    $password = hash('sha256', $salt . $hash);
     
    //sanitize username
  //  $username = mysql_real_escape_string($username);
     
   $query = "INSERT INTO member ( username, password, email, salt, agent_status, agent_name, agents_phone, agent_pic ) VALUES ( '$username', '$password', '$email', '$salt', '$agentstatus', '$agentname', '$agentphone', '$agentpic' );";
mysql_query($query);
     
   mysql_close();
     
  //  header('Location: registration.html');
  echo $password.'<br>';
   echo $salt.'<br>';
 echo $username;
?>