<?php
session_start();
require ("includes/connection.php"); // Poziva kod za konekciju na bazu podataka.

  $username = $_POST['username'];
    $password = $_POST['password'];
    
   /*  
    // OVO JE VISAK OVDE zbog require ("includes/connection.php");
    *  alien_requestapp je prava baza, a ovo je test!!
    * 
    $conn =  mysql_connect('localhost','alien_requestadm','o8^USIm]S05pd@$','alien_requestapp') or die(mysql_error());
     mysql_query("SET character_set_results=utf8", $conn);
	mysql_select_db('alien_requestapp', $conn);
	  mysql_query("set names 'utf8'",$conn);
	*/	
     
    $username = mysql_real_escape_string($username);
    $query = "SELECT id, username, password, salt, agent_status, agent_name
			FROM member
			WHERE username = '$username';";
	  
    $result = mysql_query($query);
    if(mysql_num_rows($result) == 0) // User not found. So, redirect to login_form again.
    {
	$_SESSION['odobreno']="ne";
	$_SESSION['porukalogin']="Agent username is invalid. Please try again...";
    header('Location: index.php');
    }
     
    $userData = mysql_fetch_array($result, MYSQL_ASSOC);
    $hash = hash('sha256', $userData['salt'] . hash('sha256', $password) );
	if($hash != $userData['password']) // Incorrect password. So, redirect to login_form again.
    {
		$_SESSION['odobreno']="ne";
		$_SESSION['porukalogin']="Password in incorrect. Please try again...";
		header('Location: index.php');
    }
	else{	// Redirect to home page after successful login.
		session_regenerate_id();	
		unset($_SESSION['porukalogin']);
		$_SESSION['odobreno']="da";
		$_SESSION['sess_user_id'] = $userData['id'];
		$_SESSION['sess_username'] = $userData['username'];
		$_SESSION['sess_agent_name'] = $userData['agent_name'];
	    $_SESSION['sess_agent_status'] = $userData['agent_status'];
		$_SESSION['assign_changed'] = "0";
    header('Location: index.php');
    }

?>
