<?php
unset($_SESSION['assign_changed']);
unset($_SESSION['mail_to_agent']);
unset($_SESSION['status_changed']);
$requestIDnote=$_GET['IDrequest'];
	$req = mysql_query("SELECT t1.*, t2.* FROM requests t1 INNER JOIN member t2 ON t2.id=t1.agentID WHERE t1.requestID='$requestIDnote'");
	$note = mysql_query("SELECT t1.*, t2.* FROM notes t1 INNER JOIN member t2 ON t2.id=t1.agentID WHERE t1.requestID='$requestIDnote' ORDER BY noteID DESC");
mysql_query("SET NAMES UTF8");
$row = mysql_fetch_array($req);
$idrequest=$ID;

?>

<div class="requestdetailsbox">
<div class="detailsframe">
<div class="detailshead">Quote request # <?php echo $row['requestID']?><div style="float:right;font-size:14px;padding:6px 0">Request from: <span style="color:#99BF82"><?php echo $row['request_from']?></span></div></div>
<div class="detailsbox1">
<div class="detailsclientname"><div class="titleofbox">Client</div>
Name: <b><?php echo $row['client_first_name']; echo $row['client_last_name']?></b><br>
Email: <b><?php echo $row['client_email']?></b><br>
Phone number: <b><?php echo $row['client_phone']?></b><br>
Prefers to contacted by: <b><?php echo $row['contact_by']?></b><br>
Request received: <b><?php echo $row['received_date']?></b>
</div><div class="detailsagentsnote"><div class="titleofbox">Agent notes</div>
<div class="notetext">
<?php while($requestnotes = mysql_fetch_array($note))	
	{
	echo $requestnotes['agent_name'].' ['.$requestnotes['notedate'].'] - '.$requestnotes['note'].'<br>';
	}
?>
</div>
</div>
</div>
<div class="changebutton"><button class="requestchange" id="requestchange" name="requestchange" onclick="showDiv()" >Add new note</button></div>
<div class="addanotebox"><form action="index.php?page=addanote" method="POST"><input id="addnoteidrequest" type="hidden" name="addnoteidrequest" value="<?php echo $requestIDnote ?>"><textarea id="notetextbox" name="notetextbox" required></textarea><button class="addnotesubmit" id="addnotesubmit" name="addnotesubmit" type="submit">Save a note</button></form><button class="canceladdnote" id="canceladdnote" name="canceladdnote" onclick="hideDiv()">Cancel</button></div>
<script type='text/javascript'>
function showDiv() {
	   $('.addanotebox').show('slow');
	    $('.changebutton').hide();
		   return false;

}
function hideDiv() {
	   $('.addanotebox').hide('slow');
	    $('.changebutton').show();
		return false;
}
$(document).ready(function() {
$('.backbutton').show();
});
</script>
<div class="detailshead2" style="height:auto;display: table-cell; ">
<div style="float:left; width:50%;text-align: left;"><span style="font-size:14px">Assigned to:</span><br> <span style="color:#5B8652">
<b><?php echo $row['agent_name']?></b></span></div>

<div style="float:left; width:50%;text-align: right;"><span style="font-size:14px">Status:</span><br> 
<?php
if ($row['status']=="Cancelled")
{
?>
<span style="color:#B30505">
<b><?php 
echo $row['status']; if($row['cancel_type']!="") {echo '<br><span style="font-size:12px;color:black">('.$row['cancel_type'].')</span>';} ?></b></span>
<?php
}
else
{
?>
<span style="color:#5B8652">
<b><?php 
echo $row['status']; if($row['cancel_type']!="") {echo '<br><span style="font-size:12px;color:black">('.$row['cancel_type'].')</span>';} ?></b></span>
<?php
}
?>
</div>
</div><hr>
<div class="detailshead2" style="height:auto;display: table-cell; ">
<div style="float:left; width:50%;text-align: left;"><span style="font-size:14px">All itineraries:</span><br> <span style="color:#5B8652">
<?php
$itinerarydataview = mysql_query("SELECT * FROM itineraries WHERE request_id='$requestIDnote' ORDER BY status_id ASC");
mysql_query("SET NAMES UTF8");
if(mysql_num_rows($itinerarydataview) == 0)
{
echo  '<div style="wight:200px;margin:0 auto;">No itineraries entered!</div>';
}
else
{

while($itinerarylist = mysql_fetch_assoc($itinerarydataview))
{
echo $itinerarylist["itinerary_id"].'; ';
}
}
?></span></div>

<div style="float:left; width:50%;text-align: right;"><span style="font-size:14px">Booked itinerary:</span><br> <span style="color:#5B8652">
<?php
$itinerarydatabooked = mysql_query("SELECT * FROM itineraries WHERE request_id='$requestIDnote' AND itinerary_status='Booked' ORDER BY status_id ASC");
mysql_query("SET NAMES UTF8");
if(mysql_num_rows($itinerarydatabooked) == 0)
{
echo  '<div style="wight:200px;margin:0 auto;">No booked itineraries!</div>';
}
else
{

while($itinerarylist = mysql_fetch_assoc($itinerarydatabooked))
{
echo $itinerarylist["itinerary_id"].'; ';
}
}
?></span>
</div>
</div><hr>
<div class="detailshead2">Travel details<span style="text-align:right; float:right;font-size: 14px;">Request Type: <span style="color: #5B8652;font-size:18px"><?php 
echo $row['request_type'] ?></span></span></div>

<script>
  
function offeridchange(request)
    {
	leftPos = 0
	topPos = 0
	if (screen) 
		{
		leftPos = (screen.width / 2) - 125
		topPos = (screen.height / 2) - 100
		}
	window.open('addofferid.php?id='+request,'popup','width=250,height=200,left='+leftPos+',top='+topPos+',scrollbars=0');
	}
function bookedidchange(request)
    {
	leftPos = 0
	topPos = 0
	if (screen) 
		{
		leftPos = (screen.width / 2) - 125
		topPos = (screen.height / 2) - 100
		}
	window.open('addbookedid.php?id='+request,'popup','width=250,height=200,left='+leftPos+',top='+topPos+',scrollbars=0');
	}
</script>
<!------------------------------------------------------------static part ------------------------------------------------------------------------------>
<div class="requeststaticbox" id="requeststaticbox">
<div class="detailsbox2">
<div class="detailsbox2row">
<div class="detailsbox2cell1"><div class="titleofbox">Travel dates</div>
<?php
$todaysdate=date("m/d/Y");
if ($row['check_in']<=$todaysdate)
		{
		$Starts="Not Specified";
		$Ends="Not Specified";
		echo 'Check in: <b>Not Specified</b><br>Check out: <b>Not Specified</b><br>';
		}
		else{
		$Starts=date("M d, Y", strtotime($row['check_in']));
		$Ends=date("M d, Y", strtotime($row['check_out']));
		echo 'Check in: <b>'.$Starts.'</b><br>Check out: <b>'.$Ends.'</b><br>';
	
		}
?>

Dates: <?php
if ($row['dates_flexibility']=="No")
{ echo '<b>NOT Flexible</b>';}
else{ echo '<b>Flexible</b>';}
 ?><br>
Client's note: <br>
 <b><?php echo $row['other_dates']?></b>
</div>
<div class="detailsbox2cell2"><div class="titleofbox">Travelers</div>
Adults: <b><?php echo $row['adults']?></b><br>
Children: <b><?php echo $row['children']?></b><br>
<?php switch ($row['children']) {
    case 0:
        echo '';
        break;
    case 1:
        echo 'Children ages: <br><div style="font-size:10px; margin-left:35px">
Child 1 - <b>'.$row['child1'].'</b>
</div>';
        break;
    case 2:
        echo 'Children ages: <br><div style="font-size:10px; margin-left:35px">
Child 1 - <b>'.$row['child1'].'</b><br>
Child 2 - <b>'.$row['child2'].'</b>
</div>';
        break;
	case 3:
        echo 'Children ages: <br><div style="font-size:10px; margin-left:35px">
Child 1 - <b>'.$row['child1'].'</b><br>
Child 2 - <b>'.$row['child2'].'</b><br>
Child 3 - <b>'.$row['child3'].'</b>
</div>';
        break;
	case 4:
        echo 'Children ages: <br><div style="font-size:10px; margin-left:35px">
Child 1 - <b>'.$row['child1'].'</b><br>
Child 2 - <b>'.$row['child2'].'</b><br>
Child 3 - <b>'.$row['child3'].'</b><br>
Child 4 - <b>'.$row['child4'].'</b>
</div>';
        break;
	case 5:
        echo 'Children ages: <br><div style="font-size:10px; margin-left:35px">
Child 1 - <b>'.$row['child1'].'</b><br>
Child 2 - <b>'.$row['child2'].'</b><br>
Child 3 - <b>'.$row['child3'].'</b><br>
Child 4 - <b>'.$row['child4'].'</b><br>
Child 5 - <b>'.$row['child5'].'</b>
</div>';
        break;
	case 6:
        echo 'Children ages: <br><div style="font-size:10px; margin-left:35px">
Child 1 - <b>'.$row['child1'].'</b><br>
Child 2 - <b>'.$row['child2'].'</b><br>
Child 3 - <b>'.$row['child3'].'</b><br>
Child 4 - <b>'.$row['child4'].'</b><br>
Child 5 - <b>'.$row['child5'].'</b><br>
Child 6 - <b>'.$row['child6'].'</b>
</div>';
        break;
	case 7:
        echo 'Children ages: <br><div style="font-size:10px; margin-left:35px">
Child 1 - <b>'.$row['child1'].'</b><br>
Child 2 - <b>'.$row['child2'].'</b><br>
Child 3 - <b>'.$row['child3'].'</b><br>
Child 4 - <b>'.$row['child4'].'</b><br>
Child 5 - <b>'.$row['child5'].'</b><br>
Child 6 - <b>'.$row['child6'].'</b><br>
Child 7 - <b>'.$row['child7'].'</b>
</div>';
        break;
	case 8:
        echo 'Children ages: <br><div style="font-size:10px; margin-left:35px">
Child 1 - <b>'.$row['child1'].'</b><br>
Child 2 - <b>'.$row['child2'].'</b><br>
Child 3 - <b>'.$row['child3'].'</b><br>
Child 4 - <b>'.$row['child4'].'</b><br>
Child 5 - <b>'.$row['child5'].'</b><br>
Child 6 - <b>'.$row['child6'].'</b><br>
Child 7 - <b>'.$row['child7'].'</b><br>
Child 8 - <b>'.$row['child8'].'</b>
</div>';
        break;
	case 9:
        echo 'Children ages: <br><div style="font-size:10px; margin-left:35px">
Child 1 - <b>'.$row['child1'].'</b><br>
Child 2 - <b>'.$row['child2'].'</b><br>
Child 3 - <b>'.$row['child3'].'</b><br>
Child 4 - <b>'.$row['child4'].'</b><br>
Child 5 - <b>'.$row['child5'].'</b><br>
Child 6 - <b>'.$row['child6'].'</b><br>
Child 7 - <b>'.$row['child7'].'</b><br>
Child 8 - <b>'.$row['child8'].'</b><br>
Child 9 - <b>'.$row['child9'].'</b>
</div>';
        break;
}
?>
</div>
<div class="detailsbox2cell3"><div class="titleofbox">Destination or Package</div>
First selected option:<br>
<b><?php echo $row['first_lodging']?></b>
<div class="additionalresortsbox">
Additional selected resorts:<br>
<ul>
<li><b><?php echo $row['additional_resort_1']?></b></li>
<li><b><?php echo $row['additional_resort_2']?></b></li>
<li><b><?php echo $row['additional_resort_3']?></b></li>
</ul>
</div>

</div>
<div class="detailsbox2cell4"><div class="titleofbox">Lodging</div>
First selected option:<br>
<b><?php echo $row['first_unit']?></b>
<div class="lodgingamenitiesbox"><span style="font-weight: bold; font-size:11px">Lodging Amenities:</span><br /><b><ul><li><?php echo str_replace(',', '</li><li>', $row['lodging_amenities']); ?></li></ul></b></div><div class="unitamenitiesbox"><span style="font-weight: bold; font-size:11px">Unit Amenities:</span><br /><b><ul><li><?php echo str_replace(',', '</li><li>', $row['unit_amenities']); ?></li></ul></b></div>
</div>


</div>



<div class="detailsbox3">
<div class="detailsbox3row">
<div class="detailsbox3cell1"><div class="titleofbox">Lift tickets</div>
Type: <b><?php echo $row['lift_tickets_type']?></b><br>
Lift tickets dates: <br>
<b><?php echo str_replace(',', '<br>', $row['lift_tickets_dates']); ?></b>
</div>
<div class="detailsbox3cell2"><div class="titleofbox">Lessons</div>
<b><ul><li><?php echo str_replace(',', '</li><li>', $row['lessons']); ?></li></ul></b>
</div>
<div class="detailsbox3cell3"><div class="titleofbox">Equipment rental</div>
 <b><ul><li><?php echo str_replace(',', '</li><li>', $row['equipment']); ?></li></ul></b>
</div>
<div class="detailsbox3cell4"><div class="titleofbox">Activities</div>
<b><ul><li><?php echo str_replace(',', '</li><li>', $row['activities']); ?></li></ul></b>
</div>

</div>
</div>
<div class="detailsbox4">
<div class="detailsbox4row">
<div class="detailsbox4cell1"><div class="titleofbox">Transportation</div>
Rent a Car:<br>
<?php
if ($row['rent_a_car']==NULL || $row['rent_a_car']=="" || $row['rent_a_car']==0)
{ echo '<b>Not Needed</b>';}
else{ echo '<b>Needed</b>';}
 ?>
</div>
<div class="detailsbox4cell2"><div class="titleofbox">Air Transportation</div>
Air transportation:
<?php
if ($row['air_transportation']==NULL || $row['air_transportation']=="" || $row['air_transportation']==0)
{ echo '<b>Not Needed</b>';}
else{ echo '<b>Needed</b><div class="transportationdetailsbox">Departure Date: <b>'.$row['avio_depart_date'].'</b><br>
Return Date: <b>'.$row['avio_return_date'].'</b><br>
Departure Airport: <b>'.$row['depart_airport'].'</b><br>
Arrival Airport: <b>'.$row['arrival_airport'].'</b></div>';
if ($row['airport_transp']!=0 || $row['airport_transp']!="")
{
echo 'Transportation from/to airport: <b>Needed</b>';}}
 ?>
</div>
<div class="detailsbox4cell3"><div class="titleofboxsmall">Transportation - Client's note</div>
<b><?php echo $row['transportation_note']?></b>
</div>
<div class="detailsbox4cell4"><div class="titleofboxsmall">Additional Client's note</div>
<b><?php echo $row['additional_note']?></b>
</div>

</div>
</div>
</div>
<!------------------------------------------------------------------------------------- changeable part---------------------------------------------------------->
<div class="detailshead3">ITINERARIES</div>
<div class="manageitinerary" style="width:100%;background:#DBEAD3;">
<h1 style="font-size:13px;font-weight:bold;margin: 0 0 5px 7px;">MANAGE ITINERARIES</h1>

<?php
$itinerarydata = mysql_query("SELECT * FROM itineraries WHERE request_id='$requestIDnote' ORDER BY status_id ASC");
mysql_query("SET NAMES UTF8");
if(mysql_num_rows($itinerarydata) == 0)
{
echo  '<div style="wight:200px;margin:0 auto;padding:15px;">No itineraries entered!</div><hr>';
}
else
{
?>

<table>
<tr>
<th>Itinerary ID</th>
<th>SUM $</th>
<th>Status</th>
<th></th>
<th></th>
</tr>
<?php

while($data = mysql_fetch_assoc($itinerarydata))
{
if ($data["itinerary_sum"]==NULL || $data["itinerary_sum"]=="" || $data["itinerary_sum"]==0)
	{$itinerarysum="";}
	else
	{$itinerarysum=number_format($data["itinerary_sum"],2,",",".");}
?>
<tr>
<form name="bookedid" action="index.php?page=changerecordstatus&IDrequest=<?php echo $requestIDnote ?>&change=update" method="POST">
<td><input type="hidden" name="statusid" value="<?php echo $data["status_id"] ?>"><input class="id" type="text" name="itineraryid" value="<?php echo $data["itinerary_id"] ?>"></td>
<td><input class="sum" type="text" name="itinerarysum" style="text-align:right" value="<?php echo $itinerarysum ?>" required="required"></td>
<td><select name="itinerarystatus" >
	<option value="<?php echo $data['itinerary_status'] ?>"><?php echo $data['itinerary_status'] ?></option>
	<optgroup label="-------"></optgroup>
	<option value="Quote Sent">Quote Sent</option>
	<option value="Booked">Booked</option>
	</select>
</td>
<td style="padding: 0 0 0 3px;"><button class="statusbutton" id="statusbutton" type="submit" name="statusbutton">
<img id="statusimg<?php echo $ID ?>" style="margin:2px;" src="images/save1.png" />
</button></td>
</form>
</tr>
<?php
}
?>
</table>
</fieldset>
<hr><?php
}
?>
<h1 style="font-size:13px;font-weight:bold;margin: 0 0 5px 7px;">ADD NEW ITINERARY</h1>
<table>
<tr>
<th>Itinerary ID</th>
<th>SUM $</th>
<th></th>
<th></th>
</tr>
<?php
$itinerarydata = mysql_query("SELECT * FROM itineraries WHERE request_id='$requestIDnote'");
mysql_query("SET NAMES UTF8");

?>
<tr>
<form name="bookedid" action="index.php?page=changerecordstatus&IDrequest=<?php echo $requestIDnote ?>&change=new" method="POST">
<td><input class="id" type="text" name="itineraryid"></td>
<td><input class="sum" type="text" name="itinerarysum" style="text-align:right" required="required"></td>

<td style="padding: 0 0 0 3px;"><button class="statusbutton" id="statusbutton" type="submit" name="statusbutton">
<img id="statusimg<?php echo $ID ?>" style="margin:2px;" src="images/save1.png" />
</button></td>
</form>
 
</tr>

</table>
<hr>
<h1 style="font-size:13px;font-weight:bold;margin: 0 0 5px 7px;">CANCEL QUOTE REQUEST</h1>
<table>
<tr>
<th>Status</th>
<th></th>

</tr>
<?php
$itinerarydata = mysql_query("SELECT * FROM itineraries WHERE request_id='$requestIDnote'");
mysql_query("SET NAMES UTF8");

?>
<tr>
<form name="bookedid" action="index.php?page=changerecordstatus&IDrequest=<?php echo $requestIDnote ?>&change=cancel" method="POST">
<td><select name="canceltype" >
	<option value="Duplicate">Duplicate</option>
	<option value="Expired">Expired</option>
	<option value="Not Valid">Not Valid</option>
	</select>
</td>

<td style="padding: 0 0 0 3px;"><button class="statusbutton" id="statusbutton" type="submit" name="statusbutton">
<img id="statusimg<?php echo $ID ?>" style="margin:2px;" src="images/save1.png" />
</button></td>
</form>
 
</tr>

</table>





</div>
</div>
<!-------------------------------------->
</div>
<div style="text-align:right; "><button style="cursor:pointer" class="backbutton" type="button" onclick="location.href='index.php'">back to main page</button></div>
</div>
</div>
