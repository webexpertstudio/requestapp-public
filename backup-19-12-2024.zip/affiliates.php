<?php
if($_SESSION["sess_agent_status"]!="admin") {
	die("Acces denied");
}
?>
<div id="statusbuttons">
	<button id="tab" onclick="location.href='index.php?page=affiliates'">Affiliates</button>
	<button id="tab" onclick="location.href='index.php?page=informers'">Informers</button>
	<button id="tab" onclick="location.href='index.php?page=campaigns'">Campaigns</button>
	<button id="tab" onclick="location.href='index.php?page=tracking'">Tracking Reports</button>
	<button id="tab" onclick="location.href='index.php?page=affiliate&action=new'">Add New Affiliate</button>
</div>
<div class="datatable">
<table width="100%" border="0" cellspacing="0" cellpadding="2" style="font-weight:bold;font-size: 12px;">
	<tr style="font-size: 13px;border-bottom:2px solid #000">
		<td>Affiliate Name</td>
		<td>Affiliate URL</td>
		<td>Campaigns</td>
	</tr> <?php
	$sql = "SELECT a.*, COUNT(c.`campaign_tid`) as counts 
			FROM `tbl_affiliates` a
			LEFT JOIN tbl_campaigns c ON (a.`affiliate_id`=c.`affiliate_id`)
			GROUP BY a.`affiliate_id`";
	$query=db_query($sql);
	while($row = mysql_fetch_assoc($query)) { ?>
		<tr style="font-weight:normal;">
			<td><a href="index.php?page=affiliate&action=update&affiliate_id=<?php echo $row["affiliate_id"]; ?>"><?php echo $row["affiliate_name"]; ?></a></td>
			<td><a href="index.php?page=affiliate&action=update&affiliate_id=<?php echo $row["affiliate_id"]; ?>"><?php echo $row["affiliate_url"]; ?></a></td><?php
			if($row["counts"]) { ?>
				<td><a href="index.php?page=campaigns&affiliate_id=<?php echo $row["affiliate_id"]; ?>">Show campaigns: <?php echo $row["counts"]; ?></a></td><?php
			}
			else { ?>
				<td><a href="index.php?page=campaign&action=insert&affiliate_id=<?php echo $row["affiliate_id"]; ?>">Add campaign</a></td><?php
			} ?>
		</tr> <?php
	} 
	if(!mysql_num_rows($query)) { ?>
		<tr style="font-weight:normal;">
			<td colspan="2">No saved records</td>
		</tr><?php
	} ?>
	<tr style="font-weight:normal;">
		<td colspan="3"><a href="index.php?page=affiliate&action=insert">Add new Affiliate</a></td>
	</tr>
 </table>
