<h4>Agents' Workload</h4>
<div class="agentbuttons">
<table><tr>
<?php
$assigned="Assigned";
$agentbuttons = mysql_query("SELECT * FROM member WHERE NOT id='0'");
while($agentsbuttonsdata = mysql_fetch_array($agentbuttons))
	{
	$agentidbrojac=$agentsbuttonsdata["id"];
	
	
$statuscounter = mysql_query("SELECT status FROM requests WHERE agentID='$agentidbrojac'");
$scounter = mysql_num_rows($statuscounter);
$assignedcounter = mysql_query("SELECT status FROM requests WHERE agentID='$agentidbrojac' AND status='$assigned'");	
	if($assignedcounter)
  {$acounter = mysql_num_rows($assignedcounter);}
else
  {die(mysql_error());}
	
	//$acounter = mysql_fetch_array($assignedcounter);
	if ($agentsbuttonsdata["id"]==$agent)
	{$detailsview="index.php?page=managerdetails&agentid=";}
	else{$detailsview="index.php?page=agentdetails&agentid=";}
	?>
<td>
 <div class="agentbox" >
<div class="agentbuttonleft" style="float:left">
<img src="images/agents/<?php echo $agentsbuttonsdata["agent_pic"]; ?>"></div>
<div class="agentbuttonright" style="float:right"><span style="font-size:12px;color:#506785; font-weight:bold;"><?php echo $agentsbuttonsdata["agent_name"]; ?></span><div style="margin:3px; font-size:9px; ">QR<div class="requestnum"><div class="requestnumleft">Pending<br><span style="font-weight:bold; color:red"><?php echo $acounter ?></span></div><div class="requestnumright">Total<br><b><?php echo $scounter ?></b></div></div><div class="agentdeatilsbutton"><button onClick="location='<?php echo $detailsview.''.$agentidbrojac ?>&agentname=<?php echo $agentsbuttonsdata["agent_name"] ?>&agentpic=<?php echo $agentsbuttonsdata["agent_pic"]; ?>&pendingrq=<?php echo $acounter; ?>&totalrq=<?php echo $scounter; ?>&agentstatus=<?php echo $agentsbuttonsdata["agent_status"] ?>&agentphone=<?php echo $agentsbuttonsdata["agents_phone"] ?>&agentmail=<?php echo $agentsbuttonsdata["email"] ?>'">show details</button></div></div></div>
</td>
<?php
$i++;
if($i==4)
    {
        echo "</tr>\n<tr>";
        $i=0;
    }
}
?>
</tr></table>
   </div>
                              </div>