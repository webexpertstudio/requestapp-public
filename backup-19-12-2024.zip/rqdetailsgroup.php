<?php
unset($_SESSION['assign_changed']);
unset($_SESSION['mail_to_agent']);
unset($_SESSION['status_changed']);
$requestIDnote=$_GET['IDrequest'];
	$req = mysql_query("SELECT t1.*, t2.* FROM requests t1 INNER JOIN member t2 ON t2.id=t1.agentID WHERE t1.requestID='$requestIDnote'");
	$note = mysql_query("SELECT t1.*, t2.* FROM notes t1 INNER JOIN member t2 ON t2.id=t1.agentID WHERE t1.requestID='$requestIDnote' ORDER BY noteID DESC");
mysql_query("SET NAMES UTF8");
$row = mysql_fetch_array($req);
$idrequest=$ID;

?>

<div class="requestdetailsbox" style="background:none">
<div class="detailsframe">
<div class="detailshead">Quote request # <?php echo $row['requestID']?><div style="float:right;font-size:14px;padding:6px 0">Request from: <span style="color:#99BF82"><?php echo $row['request_from']?></span></div></div>
<div class="detailsbox1">
<div class="detailsclientname"><div class="titleofbox">Client</div>
Name: <b><?php echo $row['client_first_name']; echo $row['client_last_name']?></b><br>
Email: <b><?php echo $row['client_email']?></b><br>
Phone number: <b><?php echo $row['client_phone']?></b><br>
Prefers to contacted by: <b><?php echo $row['contact_by']?></b><br>
Request received: <b><?php echo $row['received_date']?></b>
</div><div class="detailsagentsnote"><div class="titleofbox">Agent notes</div>
<div class="notetext">
<?php while($requestnotes = mysql_fetch_array($note))	
	{
	echo $requestnotes['agent_name'].' ['.$requestnotes['notedate'].'] - '.$requestnotes['note'].'<br>';
	}
?>
</div>
</div>
</div>
<div class="changebutton"><button class="requestchange" id="requestchange" name="requestchange" onclick="showDiv()" >Add new note</button></div>
<div class="addanotebox"><form action="index.php?page=addanote" method="POST"><input id="addnoteidrequest" type="hidden" name="addnoteidrequest" value="<?php echo $requestIDnote ?>"><textarea id="notetextbox" name="notetextbox" required></textarea><button class="addnotesubmit" id="addnotesubmit" name="addnotesubmit" type="submit">Save a note</button></form><button class="canceladdnote" id="canceladdnote" name="canceladdnote" onclick="hideDiv()">Cancel</button></div>
<script type='text/javascript'>
function showDiv() {
	   $('.addanotebox').show('slow');
	    $('.changebutton').hide();
		   return false;

}
function hideDiv() {
	   $('.addanotebox').hide('slow');
	    $('.changebutton').show();
		return false;
}
$(document).ready(function() {
$('.backbutton').show();
});
</script>
<div class="detailshead2" style="height:auto;display: table-cell; background:#fff ">
<div style="float:left; width:50%;text-align: left;"><span style="font-size:14px">Assigned to:</span><br> <span style="color:#5B8652">
<b><?php echo $row['agent_name']?></b></span></div>

<div style="float:left; width:50%;text-align: right;"><span style="font-size:14px">Status:</span><br> 
<?php
if ($row['status']=="Cancelled")
{
?>
<span style="color:#B30505">
<b><?php 
echo $row['status']; if($row['cancel_type']!="") {echo '<br><span style="font-size:12px;color:black">('.$row['cancel_type'].')</span>';} ?></b></span>
<?php
}
else
{
?>
<span style="color:#5B8652">
<b><?php 
echo $row['status']; if($row['cancel_type']!="") {echo '<br><span style="font-size:12px;color:black">('.$row['cancel_type'].')</span>';} ?></b></span>
<?php
}
?>
</div>
</div><hr>
<div class="detailshead2" style="height:auto;display: table-cell;  background:#fff ">
<div style="float:left; width:50%;text-align: left;"><span style="font-size:14px">All itineraries:</span><br> <span style="color:#5B8652">
<?php
$itinerarydataview = mysql_query("SELECT * FROM itineraries WHERE request_id='$requestIDnote' ORDER BY status_id ASC");
mysql_query("SET NAMES UTF8");
if(mysql_num_rows($itinerarydataview) == 0)
{
echo  '<div style="wight:200px;margin:0 auto;">No itineraries entered!</div>';
}
else
{

while($itinerarylist = mysql_fetch_assoc($itinerarydataview))
{
echo $itinerarylist["itinerary_id"].'; ';
}
}
?></span></div>

<div style="float:left; width:50%;text-align: right;"><span style="font-size:14px">Booked itinerary:</span><br> <span style="color:#5B8652">
<?php
$itinerarydatabooked = mysql_query("SELECT * FROM itineraries WHERE request_id='$requestIDnote' AND itinerary_status='Booked' ORDER BY status_id ASC");
mysql_query("SET NAMES UTF8");
if(mysql_num_rows($itinerarydatabooked) == 0)
{
echo  '<div style="wight:200px;margin:0 auto;">No booked itineraries!</div>';
}
else
{

while($itinerarylist = mysql_fetch_assoc($itinerarydatabooked))
{
echo $itinerarylist["itinerary_id"].'; ';
}
}
?></span>
</div>
</div><hr>
<div class="detailshead2">Travel details<span style="text-align:right; float:right;font-size: 14px;">Request Type: <span style="color: #5B8652;font-size:18px"><?php 
echo $row['request_type'] ?></span></span></div>

<script>
  
function offeridchange(request)
    {
	leftPos = 0
	topPos = 0
	if (screen) 
		{
		leftPos = (screen.width / 2) - 125
		topPos = (screen.height / 2) - 100
		}
	window.open('addofferid.php?id='+request,'popup','width=250,height=200,left='+leftPos+',top='+topPos+',scrollbars=0');
	}
function bookedidchange(request)
    {
	leftPos = 0
	topPos = 0
	if (screen) 
		{
		leftPos = (screen.width / 2) - 125
		topPos = (screen.height / 2) - 100
		}
	window.open('addbookedid.php?id='+request,'popup','width=250,height=200,left='+leftPos+',top='+topPos+',scrollbars=0');
	}
</script>
<!------------------------------------------------------------static part ------------------------------------------------------------------------------>
<div class="requeststaticbox" id="requeststaticbox">
<div style="margin:0">
<h2 style="text-align:left;">DATES & TRAVELERS</h2>
<div class="formframe"><h4 style="margin: 15px 0px">VACATION DATES:</h4>
<div class="block">

<div class="block-polovina">CHECK IN: <b><?php echo $row['check_in'] ?></b></div>
<div class="block-polovina">CHECK OUT: <b><?php echo $row['check_out'] ?></b></div>

</div>
<?php if( $row['dates_flexibility']=='0' || $row['dates_flexibility']=='')
{
	$flexible='No';
}
else
{
	$flexible='Yes';
}
?>
<?php if (isset($row['dates_flexibility']) || $row['dates_flexibility']!='')
{
?>
<h4 style="margin: 15px 0px">Dates are flexible</h4>
<div class="block">
<div class="block-trecina"><b><?php echo $flexible ?></b></div></div>
<?php
}
if ($row['other_dates']!='' || $row['other_dates']!=null)
{
?>
<h4 style="margin: 15px 0px">Other convenient traveling dates</h4>
<div class="block">
<div class="block-ceo"><b><?php echo $row['other_dates'] ?></b></div>
</div>
<?php
}
?>
</div>

<div class="formframe"><h4 style="margin: 15px 0px">Traveling people</h4>
<div class="block">
<div class="block-polovina">ADULTS: <b><?php echo $row['adults'] ?></b></div>
<div class="block-polovina">CHILDREN: <b><?php echo $row['children'] ?></b></div>
</div>
 </div>
<?php
if ($row['departure_group']!='' || $row['departure_group']!=null)
{
?>
<div class="formframe"><h4 style="margin: 15px 0px">Country of Departure:</h4>
<div class="block">
<div class="block-trecina">
<div class="block-polovina"><b><?php echo $row['departure_group'] ?></b></div>
</div></div></div>
<?php
}
?>
<h2 style="text-align:left">DESTINATION</h2>
<div class="formframe">
<?php
if ($row['first_lodging']!='' || $row['first_lodging']!=null)
{
?>
<h4 style="margin: 15px 0px">PRESELECTED RESORT:
</h4>
<div class="block">
<div class="block-ceo"><b><?php echo $row['first_lodging'] ?></b>
</div></div>
<?php
}
?>
<h4 style="margin: 15px 0px">RESORT: <span style="color: #8DA9E2;"></span>
</h4>
<div class="block">
<div class="block-ceo"><?php echo $row['additional_resort_1'] ?>
</div></div></div>
<h2 style="text-align:left">LODGING</h2>
<div class="formframe"><h4 style="margin: 15px 0px">Preferred lodging:</h4>
<div class="block">
<div class="block-ceo"><b><?php echo $row['lodging_type_group'] ?></b>
</div>
</div></div>
<div class="formframe"><h4 style="margin: 15px 0px">Preferred meal plan:</h4>
<div class="block-ceo"><b><?php echo $row['meal_plan_group'] ?></b>
</div></div>

<h2 style="text-align:left">TRANSPORTATION</h2>
<div class="formframe"><h4 style="margin: 15px 0px">Air transportation:</h4>
<div class="block">
<div class="block-ceo"><b><?php
if ($row['air_transportation']==NULL || $row['air_transportation']=="")
{ echo '<b>Not Needed</b>';}
else{ echo '<b>Needed</b><div class="transportationdetailsbox">';
////////
if ($row['avio_depart_date']==NULL || $row['avio_depart_date']=="" || $row['avio_depart_date']=="0000-00-00")
{
	echo 'Departure Date: <b>Not specified</b><br>';	
}
else{
	echo 'Departure Date: <b>'.$row['avio_depart_date'].'</b><br>';	
}
//////
if ($row['avio_return_date']==NULL || $row['avio_return_date']=="" || $row['avio_return_date']=="0000-00-00")
{
	echo 'Return Date: <b>Not specified</b><br>';	
}
else{
	echo 'Return Date: <b>'.$row['avio_return_date'].'</b><br>';	
}
//////////
if ($row['depart_airport']==NULL || $row['depart_airport']=="")
{
	echo 'Departure Airport:  <b>Not specified</b><br>';	
}
else{
	echo 'Departure Airport:  <b>'.$row['depart_airport'].'</b><br>';	
}
/////////
if ($row['arrival_airport']==NULL || $row['arrival_airport']=="")
{
	echo 'Arrival Airport:  <b>Not specified</b><br>';	
}
else{
	echo 'Arrival Airport:  <b>'.$row['arrival_airport'].'</b><br>';	
}
////////////
if ($row['airport_transp']!=0 || $row['airport_transp']!="" || $row['airport_transp']!=NULL)
{
echo 'Transportation from/to airport: <b>Needed</b></div>';}
}
 ?></b>
</div>
</div></div>
<div class="formframe"><h4 style="margin: 15px 0px">Preferred ground transportation:</h4>
<div class="block">
<div class="block-ceo"><b><?php echo $row['ground_transport_group'] ?></b>
</div>
</div></div>
<div class="formframe">
<div class="block">
<h4 style="margin: 15px 0px">Any additional request regarding to transportation</h4>
<div class="block"><div class="block-ceo"><b><?php echo $row['transportation_note'] ?></b></div></div></div></div>
</div>

<h2 style="text-align:left">SPECIAL REQUIREMENTS / PREFERENCES / QUESTIONS</h2>
<div class="formframe"><h4 style="margin: 15px 0px">Additional informations, requirements or preferences</h4>
<div class="block">
<div class="block-ceo"><b><?php echo $row['additional_note'] ?></b></div></div></div>
 
<h2 style="text-align:left">CONTACT INFO To whom to send this proposal</h2>
<div class="formframe"><h4 style="margin: 15px 0px">NAME:</h4>
<div class="block">
<div class="block-ceo">First name: <b><?php echo $row['client_first_name'] ?></b>
<div class="block-ceo">Last name: <b><?php echo $row['client_last_name'] ?></b></div>
<h4 style="margin: 15px 0px">CONTACT:</h4>
<div class="block">
<div class="block-ceo">Email: <b><?php echo $row['client_email'] ?></b>
<div class="block-ceo">Phone number: <b><?php echo $row['client_phone'] ?></b></div>

<h4 style="margin: 15px 0px">Additional Address Information:</h4>
<div class="block">
<div class="block-ceo">Address: <b><?php echo $row['client_address_group'] ?></b></div>
<div class="block-ceo">City: <b><?php echo $row['client_city_group'] ?></b></div>

<div class="block-ceo">State/Province: <b><?php echo $row['client_state_group'] ?></b></div>
<div class="block-ceo">Zip/Postal code: <b><?php echo $row['client_zipcode_group'] ?></b></div>

<div class="block-ceo">Country<b><?php echo $row['client_country_group'] ?></b></div></div>
<h4 style="margin: 15px 0px">Prefer to be contacted by agent</h4>
<div class="block">
<div class="block-ceo"><b><?php echo $row['contact_by'] ?></b>
</div></div>
</div>

</div>
</div>
<!-------------------------------------->
</div>
<div style="text-align:right; "><button style="cursor:pointer" class="backbutton" type="button" onclick="location.href='index.php'">back to main page</button></div>
</div>
</div>
