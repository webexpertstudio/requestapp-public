	  
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"></link>
<script src="http://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.6.4/js/bootstrap-datepicker.js"></script>	  
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" />  
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css" />    
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css"></link>
     
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>	
<style>
	td,th {
  white-space: normal !important; 
  word-wrap: break-word;  
}
table {
  table-layout: fixed;
}
div.art-logo
{
	top:35px;
}
table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after, table.dataTable thead .sorting:after
{
	content:"" !important;
}
	</style>
<script>

$(document).ready(function() {
    $('#reportingtable').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
	   $(document).ready(function () {

				 // Setup - add a text input to each footer cell
    $('#reportingtable tfoot th:not(:last-child)').each( function () {
        var title = $(this).text();
        $(this).html( '<input type="text" placeholder="Search" />' );
    } );
 
    // DataTable
    var table = $('#reportingtable').DataTable();
 
    // Apply the search
    table.columns().every( function () {
        var that = this;
 
        $( 'input', this.footer() ).on( 'keyup change', function () {
            if ( that.search() !== this.value ) {
                that
                    .search( this.value )
                    .draw();
            }
        } );
    } );
            });
    </script>
	<?php
if (isset($_GET['selecteddate']))
{
	$formatshow = 'm/d/Y';
	$reportfrom=date("Y-m-d", strtotime($_POST['reportfrom']));
	$reportto=date("Y-m-d", strtotime($_POST['reportto']));
	$reportfromshow= date ( $formatshow, strtotime ( $reportfrom ) ); 
	$reporttoshow= date ( $formatshow, strtotime ( $reportto ) ); 
}
else
{
	$format = 'Y-m-d';
	$formatshow = 'm/d/Y';
	$reportfrom = date ( "Y-m-d" );
	// - 7 days from today
	$reportfrom= date ( $format, strtotime ( '-7 day' . $reportfrom ) ); 
	$reportto=date("Y-m-d");
	$reportfromshow= date ( $formatshow, strtotime ( $reportfrom ) ); 
	$reporttoshow=date("m/d/Y");
}
?>
<div style="height:60px" class="reportingform">
<div style="width:40%;float:left;"><h1>REPORTING</h1></div>
<div style="width:60%;float:right;text-align:right"><h5>SELECT DATE RANGE</h5><form name="reportingquery" action="index.php?page=reporting&selecteddate" method="POST">
<label for="reportfrom">From</label><input type="text" class="from" name="reportfrom" value="<?php echo $reportfromshow ?>" required>
<label for="reportto">To</label><input type="text" class="to" name="reportto" value="<?php echo $reporttoshow ?>"  required>
<button class="backbutton" id="backbutton" type="submit" name="statusbutton">
<img id="statusimg<?php echo $ID ?>" style="margin:2px;" src="images/save1.png" />
</button>
</form>
</div></div>
<?php

$sql = "SELECT c.`campaign_tid`, c.`campaign_name`, a.`affiliate_name` 
	FROM `tbl_campaigns` c
	JOIN `tbl_affiliates` a ON (a.`affiliate_id`=c.`affiliate_id`) ";
$query=db_query($sql);
$campaigns = array();
while($row = mysql_fetch_assoc($query)) { 
	$campaigns[$row["campaign_tid"]]["campaign_name"] = $row["campaign_name"];
	$campaigns[$row["campaign_tid"]]["affiliate_name"] = $row["affiliate_name"];
}

$reqnum = mysql_query("SELECT t1.*, t2.* FROM requests t1 INNER JOIN member t2 ON t2.id=t1.agentID WHERE t1.last_change BETWEEN '$reportfrom' AND '$reportto' GROUP BY t1.requestID ORDER BY t1.last_change DESC") or die ("Baza nije dostupna 3!");

//$reqnum = mysql_query("SELECT * FROM requests WHERE last_change BETWEEN '$reportfrom' AND '$reportto' GROUP BY requestID") or die ("Baza nije dostupna 3!");
$totalsum=0;
mysql_query("SET NAMES UTF8");
if(mysql_num_rows($reqnum) == 0)
{
echo  '<div class="norequests">No request</div>';
}
else
{

 ///////////////////

			
 /////////////////////////
?>

<div class="datatablereport">
<table id="reportingtable" width="100%" border="0" cellspacing="0" cellpadding="2" style="font-weight:bold;font-size: 12px;">
	 <thead>
	 <tr style="font-size: 11px;border-bottom:2px solid #000; background:#526486; color:#fff">
		<th>ID</th>
		<th style="text-align:center;">QR Received</th>
		<th style="width:20px">Client</th>
				<th style="text-align:center;">Client's email</th>
			<th style="text-align:center;">Destination</th>
				<th style="text-align:center;">Departure date</th>
			<th>QR from</td>
		<th>Agent</td>
		<th style="text-align:center;">QR Status</th>
			<th style="text-align:center;color:#99BF82;">$ BOOKED</th>
	</tr>
	</thead>
	 <tbody>
	<?php

while($data = mysql_fetch_assoc($reqnum))
	{

			$ID=$data["requestID"];
			$agentname=$data["agent_name"];
			$Sender=$data["client_first_name"].' '.$data["client_last_name"];
			$Received=date("M d, Y", strtotime($data["received_date"]));
			$last_change=date("M d, Y", strtotime($data["last_change"] ));
			$Status=$data["status"];
			$campaign_name = "";
			$affiliate_name = "";
			if($data["session_key"]) {
				$campaign_tid = "";
				$sql = "SELECT `campaign_tid` FROM `tbl_feedbacks` WHERE `session_key`='".$data["session_key"]."' LIMIT 1";
				$query=db_query($sql);
				list($campaign_tid) = mysql_fetch_row($query);
				if($campaign_tid) {
					$campaign_name = $campaigns[$campaign_tid]["campaign_name"];
					$affiliate_name = $campaigns[$campaign_tid]["affiliate_name"];
				}
			}
			//if($data['status']=="Booked" || $data['status']=="Cancelled")
			//{$Status=$data["status"];} else {$Status="";}

			if($data['finalized_date']==NULL || $data['finalized_date']=="" || $data['finalized_date']==0 || $data['finalized_date']=="0000-00-00")
			{$Statusdate="";}
			else{$Statusdate=date("M d,Y", strtotime($data["finalized_date"]));}
		?>
			<tr style="font-weight:bold;background:#CAE6F1; ">
				<td><a href="index.php?page=rqdetails&IDrequest=<?php echo $ID ?>"><?php echo $ID ?></a></td>
				<td style="text-align:center;"><?php echo $Received ?></td>
				<td><?php echo $Sender ?></td>
			<!--	<td><a href="index.php?page=tracking&report=history&session_key=<?php// echo $data["session_key"]; ?>"><?php //echo $affiliate_name; // echo $campaign_name; ?></a></td>-->
			<td><?php echo $data["client_email"]; ?></td>
			<td><?php echo $data["first_lodging"]; ?></td>
			<td style="text-align:center;"><?php echo $data["check_in"]; ?></td>
			<td><?php echo $data["request_from"]; ?></td>
				<td><?php echo $agentname ?></td>
				
				
				
					
					
					<?php if($Status=="Booked")
					{ 
						echo '<td style="text-align:center;width:80px;color:#2A9902;">'.$Status.'</td>';
					
					}
					elseif($Status=="Cancelled")
					{echo '<td style="text-align:center;width:80px;color:#5585B6;">'.$Status.'<br><span style="font-size:9px;">('.$data["cancel_type"].')</span></td>';}
					else
					{echo '<td style="text-align:center;width:80px;">'.$Status.'</td>';}
				?>
				
				
				
				<td></td>
			</tr>
				<!-- itinerary list -->
			
		<?php
		$idrequest=$ID;

	$itinerarydata = mysql_query("SELECT t1.*, t2.* FROM itineraries t1 INNER JOIN member t2 ON t2.id=t1.agent_id WHERE request_id='$idrequest' AND (change_date BETWEEN '$reportfrom' AND '$reportto') ORDER BY status_id ASC");

		mysql_query("SET NAMES UTF8");
	
			while($itdata = mysql_fetch_assoc($itinerarydata))
			{
				$last_change_itin=date("M d, Y", strtotime($itdata["change_date"] ));
				if ($itdata["itinerary_sum"]==NULL || $itdata["itinerary_sum"]=="" || $itdata["itinerary_sum"]==0)
					{$itinerarysum="";}
					else
					{$itinerarysum='$'.number_format($itdata["itinerary_sum"],2,",",".");}
				?>
				<tr style="font-weight:normal;">
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td style="background:#fff;"><?php echo $itdata['agent_name'] ?></td>
					<?php if($itdata['itinerary_status']=="Booked")
					{ $totalsum=$totalsum+$itdata['itinerary_sum'];
					?>
					<td style="text-align:center;background:#fff;color:#2A9902;font-weight:bold"><?php echo $itdata['itinerary_status'] ?></td>
					<td style="text-align:center;background:#fff;"><?php echo $last_change_itin ?></td>
					<td style="text-align:center;background:#fff;color:#2A9902;font-weight:bold"><?php echo $itdata['itinerary_id'] ?></td>
					<td style="text-align:right;background:#fff;"><?php echo $itinerarysum ?></td>
					<td></td>
					<td></td>
					
					<td style="text-align:right;background:#fff;color:#2A9902;font-weight:bold">$<?php echo $itinerarysum ?></td>
					<?php
					}
					else
					{
						?>
						<td style="text-align:center;background:#fff;"><?php echo $itdata['itinerary_status'] ?></td>
					<td style="text-align:center;background:#fff;"><?php echo $last_change_itin ?></td>
					<td style="text-align:center;background:#fff;"><?php echo $itdata['itinerary_id'] ?></td>
						<td style="text-align:right;background:#fff;"><?php echo $itinerarysum ?></td>
					<td></td>
					<td></td>
					
					<td style="background:#fff"></td>
						<?php
						
					}

					?>
				</tr>
				
			<?php
			}


		
		}
		$totalsum=number_format($totalsum,2,",",".");
		?>
		</tbody>
		 <tfoot>
            <tr>
                <th>ID</th>
		<th style="text-align:center;">QR Received</th>
		<th style="width:20px">Client</th>
				<th style="text-align:center;">Client's email</th>
			<th style="text-align:center;">Destination</th>
				<th style="text-align:center;">Departure date</th>
			<th>QR from</td>
		<th>Agent</td>
		<th style="text-align:center;">QR Status</th>
			<th style="text-align:center;color:#99BF82;">$ BOOKED</th>
            </tr>
        </tfoot>
 </table>
 </div>
<?php
	
?>
	<table width="100%" border="0" cellspacing="0" cellpadding="2" style="font-weight:bold;font-size: 12px;margin-top:15px;">
	<tr style="font-size: 14px;border-top:2px solid #000">		
					<td style="background:#F1C232; text-align:right;"><?php echo 'TOTAL BOOKED SUM:   $'.$totalsum ?></td>
					
	</tr>
 </table>
 <?php
}
?>