<?php
$requestIDmail = $_GET['IDrequestmail'];
	$agentnamerequestmail = $_GET['agentnamerequestmail'];
//$req = mysql_query("SELECT t1.*, t2.* FROM requests t1 INNER JOIN member t2 ON t2.id=t1.agentID AND t1.requestID='$requestIDmail'");
$req = mysql_query("SELECT t1.*, t2.* FROM requests t1 INNER JOIN member t2 ON t2.id=t1.agentID");
mysql_query("SET NAMES UTF8");
while($data = mysql_fetch_array($req)){
if($data["requestID"] == $requestIDmail)
{

$checkindateinput= date("M d,Y", strtotime($data["check_in"]));
$checkoutdateinput = date("M d,Y", strtotime($data["check_out"]));
$flexibledatesinput = $data["dates_flexibility"];
if ($flexibledatesinput ==0)
{
	$flexibledatesinput="No";
}
$otherconvenientdatesinput = $data["other_dates"];
$adultsinput = $data["adults"];
$childreninput = $data["children"];
$child1ageinput = $data["child1"];
$child2ageinput = $data["child2"];
$child3ageinput = $data["child3"];
$child4ageinput = $data["child4"];
$child5ageinput = $data["child5"];
$child6ageinput = $data["child6"];
$child7ageinput = $data["child7"];
$child8ageinput = $data["child8"];
$child9ageinput = $data["child9"];
$selectedresortinput = $data["first_lodging"];
$additionalresort1input = $data["additional_resort_1"];
$additionalresort2input = $data["additional_resort_2"];
$additionalresort3input = $data["additional_resort_3"];
$selectedlodginginput = $data["first_unit"];
$lodgingoptioninput = $data["lodging_amenities"];
$lodgingamenitiesinput = $data["unit_amenities"];
$liftticketselection = $data["lift_tickets_type"];
$liftticketdateinput = $data["lift_tickets_dates"];
$lessonsinput = $data["lessons"];
$otheractivitiesinput = $data["activities"];
$equipmentinput = $data["equipment"];
$rentacarinput = $data["rent_a_car"];
if ($rentacarinput ==0)
{
	$rentacarinput="No";
}
$airtransportinput = $data["air_transportation"];
if ($airtransportinput ==0)
{
	$airtransportinput="No";
}
$airdeparturedateinput = date("M d,Y", strtotime($data["avio_depart_date"]));
if ($airdeparturedateinput =="Nov 30,-0001" || $airdeparturedateinput =="Dec 31,1969")
{
	$airdeparturedateinput="";
}
$airreturndateinput = date("M d,Y", strtotime($data["avio_return_date"]));

if ($airreturndateinput =="Nov 30,-0001" || $airdeparturedateinput =="Dec 31,1969")
{
	$airreturndateinput="";
}
$departureairportinput = $data["depart_airport"];
$arrivalairportinput = $data["arrival_airport"];
$transportationfromtoairportinput = $data["airport_transp"];
if ($transportationfromtoairportinput ==0)
{
	$transportationfromtoairportinput="No";
}
$transportationnoteinput = $data["transportation_note"];
$firstnameinput = $data["client_first_name"];
$lastnameinput = $data["client_last_name"];
$emailinput = $data["client_email"];
$phoneinput = $data["client_phone"];
$contactwayinput = $data["contact_by"];
$additionalnote = $data["additional_note"];
$phoneinput = $data["client_phone"];

$receiveddate= date("Y-m-d", strtotime($data["received_date"]));


$status="New";
$toagent =$data["email"];
$agentname=$data["agent_name"];
$subject = 'Alpine Adventures - Quote Request';

$headers = "From: Alpine Adventures <tanya@alpineadventures.net>\r\n"; 
$headers .= "Reply-To: tanya@alpineadventures.net\r\n";
$headers .= "Return-Path: tanya@alpineadventures.net\r\n";
$headers .= "BCC: lanavujicic@gmail.com\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

///////////////////////////////////////////////clientmailend
//agent
$messageagent = '<html><body>';
$messageagent .= '<div style="width:657px; font-family:Arial, Helvetica, sans-serif; font-size:12px; padding:5px; border:1px solid #CCC"><img src="http://alpineadventures.net/requestapp/php/email-header.jpg">
<div style="padding:10px 0px;"><div style="border-bottom:2px solid #4A658D; color:#546586; font-size:16px; font-weight:bold; text-align:center">QUOTE REQUEST SUMMARY</div>
<div style="color:#546586; font-size:14px; font-weight:bold; padding-left:5px; padding-top:10px">DATES & TRAVELERS</div>
<div style="border:1px solid #CCC; padding:1px">
  <table width="100%" border="0" cellspacing="3" cellpadding="0" style="font-size:12px">
  <tr>
    <td colspan="2" style="background:#869BB6; padding:5px; color:#fff; font-size:13px; font-weight:bold">Date flexibility</td>
    </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Check in</td>
    <td style="padding:5px;">'.$checkindateinput.'</td>
  </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Check out</td>
    <td style="padding:5px;">'.$checkoutdateinput.'</td>
  </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Dates are flexible</td>
    <td style="padding:5px;">'.$flexibledatesinput.'</td>
  </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Other convenient dates</td>
    <td style="padding:5px;">'.$otherconvenientdatesinput.'</td>
  </tr>
   <td colspan="2" style="background:#869BB6; padding:5px; color:#fff; font-size:13px; font-weight:bold">Travelers</td>
    </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Adults</td>
    <td style="padding:5px;">'.$adultsinput.'</td>
  </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Children</td>
    <td style="padding:5px;">'.$childreninput.'</td>
  </tr>';
  switch ($childreninput) {
   case "1":
 $messageagent .= ' <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Child 1 age</td>
    <td style="padding:5px;">'.$Child1ageinput.'</td>
  </tr>';
  break;
   case "2":
 $messageagent .= '  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Child 2 age</td>
    <td style="padding:5px;">'.$Child2ageinput.'</td>
  </tr>';
  break;
   case "3":
  $messageagent .= ' <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Child 3 age</td>
    <td style="padding:5px;">'.$Child3ageinput.'</td>
  </tr>';
  break;
   case "4":
  $messageagent .= ' <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Child 4 age</td>
    <td style="padding:5px;">'.$Child4ageinput.'</td>
  </tr>';
  break;
   case "5":
  $messageagent .= ' <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Child 5 age</td>
    <td style="padding:5px;">'.$Child5ageinput.'</td>
  </tr>';
  break;
   case "6":
   $messageagent .= '<tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Child 6 age</td>
    <td style="padding:5px;">'.$Child6ageinput.'</td>
  </tr>';
  break;
   case "7":
  $messageagent .= ' <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Child 7 age</td>
    <td style="padding:5px;">'.$Child7ageinput.'</td>
  </tr>';
  break;
   case "8":
  $messageagent .= ' <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Child 8 age</td>
    <td style="padding:5px;">'.$Child8ageinput.'</td>
  </tr>';
  break;
   case "9":
   $messageagent .= '<tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Child 9 age</td>
    <td style="padding:5px;">'.$Child9ageinput.'</td>
  </tr>';
  break;
    };
$messageagent .= '</table>
</div>
<div style="color:#546586; font-size:14px; font-weight:bold; padding-left:5px; padding-top:10px">DESTINATION</div>
<div style="border:1px solid #CCC; padding:1px">
  <table width="100%" border="0" cellspacing="3" cellpadding="0" style="font-size:12px">
  <tr>
    <td colspan="2" style="background:#869BB6; padding:5px; color:#fff; font-size:13px; font-weight:bold">Resort</td>
    </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">First selected resort</td>
    <td style="padding:5px;">'.$selectedresortinput.'</td>
  </tr>';
  if ($additionalresort1input !=""){
 $messageagent .= '<tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Additional Resort 1</td>
    <td style="padding:5px;">'.$additionalresort1input.'</td>
  </tr>';
  };
   if ($additionalresort2input !=""){
 $messageagent .= ' <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Additional Resort 2</td>
    <td style="padding:5px;">'.$additionalresort2input.'</td>
  </tr>';
  };
   if ($additionalresort3input !=""){
 $messageagent .= '
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Additional Resort 3</td>
    <td style="padding:5px;">'.$additionalresort3input.'</td>
  </tr>
  ';
  };
  $messageagent .= ' <td colspan="2" style="background:#869BB6; padding:5px; color:#fff; font-size:13px; font-weight:bold">Lodging</td>
    </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">First selected lodging</td>
    <td style="padding:5px;">'.$selectedlodginginput.'</td>
  </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Lodging options</td>
    <td style="padding:5px;">'.$lodgingoptioninput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Lodging amenities</td>
    <td style="padding:5px;">'.$lodgingamenitiesinput.'</td>
  </tr>
</table>
</div>
<div style="color:#546586; font-size:14px; font-weight:bold;padding-left:5px; padding-top:10px">LIFT TICKETS</div>
<div style="border:1px solid #CCC; padding:1px">
  <table width="100%" border="0" cellspacing="3" cellpadding="0" style="font-size:12px">
  <tr>
    <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Lift tickets</td>
    <td style="padding:5px;">'.$liftticketselection.'</td>
  </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%"></td>
    <td style="padding:5px;">'.$liftticketdateinput.'</td>
  </tr>
</table>
</div>
<div style="color:#546586; font-size:14px; font-weight:bold;padding-left:5px; padding-top:10px">ACTIVITIES</div>
<div style="border:1px solid #CCC; padding:1px">
  <table width="100%" border="0" cellspacing="3" cellpadding="0" style="font-size:12px">
  <tr>
    <tr style="background:#ECEFF4;">
    <td style="padding:5px;  width:35%">Lessons</td>
    <td style="padding:5px;">'.$lessonsinput.'</td>
  </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Aditional activities</td>
    <td style="padding:5px;">'.$otheractivitiesinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Equipment</td>
    <td style="padding:5px;">'.$equipmentinput.'</td>
  </tr>
</table>
</div>
<div style="color:#546586; font-size:14px; font-weight:bold;padding-left:5px; padding-top:10px">TRANSPORTATION</div>
<div style="border:1px solid #CCC; padding:1px">
  <table width="100%" border="0" cellspacing="3" cellpadding="0" style="font-size:12px">
   <td colspan="2" style="background:#869BB6; padding:5px; color:#fff; font-size:13px; font-weight:bold">Rent a car</td>
  <tr>
    <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Car pickup location</td>
    <td style="padding:5px;">'.$carpickuplocationinput.'</td>
  </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Car drop off location</td>
    <td style="padding:5px;">'.$cardropofflocationinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Car pickup date</td>
    <td style="padding:5px;">'.$carfromdateinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Car drop off date</td>
    <td style="padding:5px;">'.$cartodateinput.'</td>
  </tr>
    <td colspan="2" style="background:#869BB6; padding:5px; color:#fff; font-size:13px; font-weight:bold">Air transportation</td>
  <tr>
    <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Departure Date</td>
    <td style="padding:5px;">'.$airdeparturedateinput.'</td>
  </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Return Date</td>
    <td style="padding:5px;">'.$airreturndateinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Departure Airport</td>
    <td style="padding:5px;">'.$departureairportinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Arrival Airporte</td>
    <td style="padding:5px;">'.$arrivalairportinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Airport transportation</td>
    <td style="padding:5px;">'.$transportationfromtoairportinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Airport transportation note</td>
    <td style="padding:5px;">'.$airporttransportationnoteinput.'</td>
  </tr>
</table>
</div>
<div style="color:#546586; font-size:14px; font-weight:bold;padding-left:5px; padding-top:10px">CONTACT INFO</div>
<div style="border:1px solid #CCC; padding:1px">
  <table width="100%" border="0" cellspacing="3" cellpadding="0" style="font-size:12px">
  
  <tr>
    <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">First name</td>
    <td style="padding:5px;">'.$firstnameinput.'</td>
  </tr>
  <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Last lastnameinputname</td>
    <td style="padding:5px;">'.$lastnameinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Email</td>
    <td style="padding:5px;">'.$emailinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Phone</td>
    <td style="padding:5px;">'.$phoneinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Want to be contacted...</td>
    <td style="padding:5px;">'.$contactwayinput.'</td>
  </tr>
   <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Airport transportation note</td>
    <td style="padding:5px;">'.$additionalnote.'</td>
  </tr>
</table>
</div>
<div style="color:#546586; font-size:14px; font-weight:bold;padding-left:5px; padding-top:10px">ADDITIONAL NOTE</div>
<div style="border:1px solid #CCC; padding:1px">
  <table width="100%" border="0" cellspacing="3" cellpadding="0" style="font-size:12px">
  
  <tr>
    <tr style="background:#ECEFF4;">
    <td style="padding:5px; width:35%">Message to agent</td>
    <td style="padding:5px;">'.$phoneinput.'</td>
  </tr>
</table>
</div>
</div>
</div>
</div>';
$messageagent .= "</body></html>";
///////////////////////////////////////////////////////agentmailend


}
}
mail($toagent, $subject, $messageagent, $headers);
header('Location: ' . $_SERVER['HTTP_REFERER']);









?>