<?php 
function input_db($input, $type="str") {
	if($type=="str") {
		$input = str_replace(";", "", $input);
		$input = str_replace("DELIMITER", "", $input);
		$input = str_replace("DROP", "", $input);
	}
	elseif($type=="int") {
		$input = (int) $input;
	}
	$input = filter_var($input, FILTER_SANITIZE_STRING);
	return mysql_real_escape_string($input);
}
function db_query($sql) {
	$query = mysql_query($sql);
	if(!$query) {
		die($sql." - ".mysql_error());
	}
	return $query;
}
function exec_query($sql) {
	$query = mysql_query($sql);
	if(!$query) {
		die($sql." - ".mysql_error());
	}
}

?>
