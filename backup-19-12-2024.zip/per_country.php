<?php
	if($_SESSION["sess_agent_status"]!="admin") {
		die("Acces denied");
	}  ?>
	<tr style="font-size: 13px;border-bottom:2px solid #000">
		<td>Country</td>
		<td width="200px">Campaign</td>
		<td width="60px">Total</td>
		<td width="60px">%</td>
	</tr> <?php
	$sql = "SELECT `campaign_tid`, `campaign_name`
			FROM tbl_campaigns ";
	$query=db_query($sql);
	$campaigns = array();
	while($row = mysql_fetch_assoc($query)) { 
		$campaigns[$row["campaign_tid"]] = $row["campaign_name"];
	}
	
	$sql = "SELECT f.`client_country`, f.`campaign_tid`, COUNT(DISTINCT f.`session_key`) as num
			FROM `tbl_feedbacks` f ";
	$sql.= $WHERE;	
	$sql.= " GROUP BY f.`client_country`, f.`campaign_tid`
			ORDER BY f.`client_country`, f.`campaign_tid`";
	$query=db_query($sql);
	$total_sum = 0;
	while($row = mysql_fetch_assoc($query)) { 
		$data[$row["client_country"]][$row["campaign_tid"]] = $row["num"];
		$total_sum = $total_sum + $row["num"];
	}
	foreach($data as $client_country=>$lv1) { 
		foreach($lv1 as $campaign_tid=>$num) { ?>
			<tr style="font-weight:normal;">
				<td><a href="index.php?page=tracking&report=history&country=<?php echo $client_country; ?>&campaign_tid=<?php echo $campaign_tid; ?>"><?php echo $client_country?$client_country:"(unknown)"; ?></a></td>
				<td><a href="index.php?page=tracking&report=history&country=<?php echo $client_country; ?>&campaign_tid=<?php echo $campaign_tid; ?>"><?php echo $campaigns[$campaign_tid]?$campaigns[$campaign_tid]:"-"; ?></a></td>
				<td><a href=""><?php echo $num ?></a></td>
				<td><a href=""><?php echo ($total_sum)?round($num/$total_sum*100, 2):"-"; ?></a></td>
			</tr> <?php
		} 
	} 
	if(!mysql_num_rows($query)) { ?>
		<tr style="font-weight:normal;">
			<td colspan="4"><font color="red">No data for selected filter !</font></td>
		</tr><?php
	} ?>
	<tr style="font-size: 13px;border-bottom:2px solid #000">
		<td></td>
		<td></td>
		<td><?php echo $total_sum; ?></td>
		<td>100%</td>
	</tr>
