<?php
if($_SESSION["sess_agent_status"]!="admin" && $_SESSION["sess_agent_status"]!="manager") {
	die("Acces denied");
} 

if($_SESSION["sess_agent_status"]=="manager") {
	$sql = "SELECT m.* 
			FROM member m
			JOIN manager_agents ma ON (
				m.id=ma.agent_id 
				AND ma.manager_id=".input_db($_SESSION['sess_user_id'])."
			)
			WHERE m.id!='0'";
}
elseif($_SESSION["sess_agent_status"]=="admin") {
	$sql = "SELECT * FROM member WHERE NOT id='0'";
}

$agents=mysql_query($sql);
while($agentsdata = mysql_fetch_array($agents))	
	{
	$agentsdropbox.='<option value="'.$agentsdata["agent_name"].'">'.$agentsdata["agent_name"].'</option>';
	}
	$agentsdropbox.='</select>';
$statusdropbox.='<option value="">-</option><option value="Quote Sent">Quote Sent</option><option value="Offer Reminder">Offer Reminder</option><option value="Booked">Booked</option><option value="Cancelled">Cancelled</option></select>';
//open view
?>
<div id="statusbuttons">
<div style="float: left;padding: 2px;width: 65px;">Requests:</div> 
<button id="tab" onclick="location.href='index.php?page=managerview'">All</button>
<button id="tab" onclick="location.href='index.php?page=managerview&status=New'">New</button>
<button id="tab" onclick="location.href='index.php?page=managerview&status=Quote Sent'">Quote Sent</button>
<button id="tab" onclick="location.href='index.php?page=managerview&status=Booked'">Booked</button>
<button id="tab" onclick="location.href='index.php?page=managerview&status=Cancelled'">Cancelled</button><br>
</div>
<?php

require ("tables-manager.php");

require ("workflow.php");
	


// Open table row

if (isset($_GET['rqopen']))
{
	?>
<script>
	$(document).ready(function(){
        $(".cat<?php echo $_GET['rqopen'] ?>").show();
    });
</script>
<?php
}
?>