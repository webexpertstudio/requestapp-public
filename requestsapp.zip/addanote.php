<?php
$idrequest=$_POST['addnoteidrequest'];
$agentid=$_SESSION['sess_user_id'];
$notedate= date("Y-m-d H:i:s");
$note=$_POST['notetextbox'];
$sqlnote = "INSERT INTO notes (requestID,agentID,notedate,note) VALUES ('$idrequest','$agentid','$notedate','$note')"; 
mysql_query($sqlnote) or die ("Baza nije dostupna!");
	

unset($_SESSION['assign_changed']);
unset($_SESSION['mail_to_agent']);
 $_SESSION['requestID']=$idrequest;
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>