<?php
	if($_SESSION["sess_agent_status"]!="admin") {
		die("Acces denied");
	}
	// ako je postovano
	$args = array(
		'id' => FILTER_VALIDATE_INT, 
		'save' => FILTER_SANITIZE_STRING,
		'agent_status' => FILTER_SANITIZE_STRING,
		'agent_id' => array(
				'filter' => FILTER_VALIDATE_INT,
				'flags' => FILTER_FORCE_ARRAY,
		),
	);
	$post = filter_input_array(INPUT_POST, $args);
	if(isset($post["save"]) && isset($post["id"])) {
		if(isset($post["agent_status"])) {
			$sql = "UPDATE member SET agent_status='".input_db($post["agent_status"])."' WHERE id=".input_db($post["id"]);
			exec_query($sql);
		}
		if(isset($post["agent_id"])) {
			// clear all agents before update
			$sql = "DELETE FROM manager_agents WHERE manager_id=".input_db($post["id"]);
			exec_query($sql);
			
			foreach($post["agent_id"] as $agent_id) {
				$sql = "INSERT INTO manager_agents SET agent_id=".input_db($agent_id).", manager_id=".input_db($post["id"]);
				exec_query($sql);
			}
		}
	}
	
	// get
	$args = array(
		'id' => FILTER_VALIDATE_INT, 
	);
	$get = filter_input_array(INPUT_GET, $args);
	if(isset($get["id"])) {
		$query=db_query("SELECT * FROM member WHERE id=".input_db($get["id"]));
		$row = mysql_fetch_assoc($query);
	}
?>
<form method="POST">
	<input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
	<div class="datatable">
		<table width="100%" border="0" cellspacing="0" cellpadding="2" style="font-weight:bold;font-size: 12px;">
			<tr>
				<td width="15%">Username:</td>
				<td><?php echo isset($row["username"])?$row["username"]:""; ?></td>
			</tr>
			<tr>
				<td width="15%">Name:</td>
				<td><?php echo isset($row["agent_name"])?$row["agent_name"]:""; ?></td>
			</tr>
			<tr>
				<td width="15%">Role:</td>
				<td>
					<select name="agent_status" OnChange="save.click();">
						<option value="agent" <?php echo ($row["agent_status"]=="agent")?"selected":"" ?>>Agent</option>
						<option value="manager" <?php echo ($row["agent_status"]=="manager")?"selected":"" ?>>Manager</option>
						<option value="admin" <?php echo ($row["agent_status"]=="admin")?"selected":"" ?>>Admin</option>
					</select>
				</td>
			</tr><?php
			if($row["agent_status"]=="manager")	{ ?>
				<tr>
					<td></td>
					<td>
						Allow to adminstrate agents:<br><?php
						$sql = "SELECT m.id, m.agent_name, ma. agent_id as my_agent
								FROM member m
								LEFT JOIN manager_agents ma ON (m.id=ma.agent_id AND ma.manager_id=".input_db($get["id"]).")
								WHERE agent_status='agent'";
						$query=db_query($sql);
						while($row = mysql_fetch_assoc($query)) { ?>
							<input type="checkbox" name="agent_id[]" value="<?php echo $row["id"];?>" <?php echo (isset($row["my_agent"]))?"checked":"";?>> <?php echo $row["agent_name"];?><br><?php 
						} ?>
					</td>
				</tr><?php
			}
			?>
			<tr>
				<td colspan="2" align="center">
					<input type="submit" id="save" name="save" value="Save">
				</td>
			</tr>
		 </table>
	</div>
</form>
