<?php
	if($_SESSION["sess_agent_status"]!="admin") {
		die("Acces denied");
	} ?>

	<tr style="font-size: 13px;border-bottom:2px solid #000">
		<td colspan="2">Page Title</td>
		<td align="center" width="60px">Average Time on Page [s]</td>
		<td align="center" width="60px">Number of Visits</td>
		<td align="center" width="60px">%</td>
	</tr> <?php

	$sql = "SELECT `informer_id`, `informer_url`
			FROM tbl_informers i ";
	$query=db_query($sql);
	$informers = array();
	while($row = mysql_fetch_assoc($query)) { 
		$informers[$row["informer_id"]] = $row["informer_url"];
	}

	$sql = "SELECT 
				f.`title`, 
				f.`informer_id`, 
				f.`URI`, 
				COUNT(DISTINCT f.`session_key`) as num, 
				AVG(TIME_TO_SEC(TIMEDIFF(`active_until`, `inserted`))) as avg_stay
			FROM tbl_feedbacks f ";
	$sql.= $WHERE;
	$sql.= " GROUP BY f.`informer_id`, f.`title`, f.`URI`
			ORDER BY f.`title`";
	// echo $sql;
	$query=db_query($sql);
	$total_sum = 0;
	while($row = mysql_fetch_assoc($query)) { 
		if(!$row["title"]) {
			$row["title"] = "(no title / not found)";
		}
		if(isset($informers[$row["informer_id"]])) {
			$row["URI"] = $informers[$row["informer_id"]].$row["URI"];
		}
		
		$data[$row["title"]][$row["URI"]]["num"] = $row["num"];
		
		$data[$row["title"]][$row["URI"]]["avg_stay"] = $row["avg_stay"];
		
		$total_sum = $total_sum + $row["num"];
	}
	// print_r($local_sum);
	$id = 0;
	foreach($data as $title=>$lv1) { 
		$id++; 
		$local_sum = 0;
		$local_avg = 0;
		foreach($lv1 as $URI=>$lv2) {
			$local_sum = $local_sum + $lv2["num"];
		}
		$sum_avg = 0;
		foreach($lv1 as $URI=>$lv2) {
			$sum_avg = $sum_avg + $lv2["avg_stay"]*$lv2["num"];
		}
		$local_avg = ($local_sum>0)?$sum_avg/$local_sum:0;
		if(count($lv1)>1) { ?>
			<tr style="font-weight:normal;">
				<td colspan="2">
					<a href="javascript:toggleMessage('<?php echo $id; ?>');">
						<img border="0" align="left" id="toggle_img_<?php echo $id; ?>" src="images/plus.gif">
					</a>
					<a href="index.php?page=tracking&report=history&from=<?php echo $get["from"]; ?>&to=<?php echo $get["to"]; ?>&title=<?php echo urlencode($title); ?>"><?php echo $title; ?></a>
				</td>
				<td align="center"><a href=""><?php echo round($local_avg, 1); ?> [s]</a></td>
				<td align="center"><a href=""><?php echo $local_sum; ?></a></td>
				<td align="center"><a href=""><?php echo ($total_sum>0)?round($local_sum/$total_sum*100, 2):"-"; ?> %</a></td>
			</tr> 
			<tr id="msg_<?php echo $id; ?>" class="slideHidden" >
				<td colspan="7">
					<table width="95%" align="right"><?php
					foreach($lv1 as $URI=>$lv2) { ?>
						<tr >
							<td>
								<a target="_blank" href="<?php echo $URI; ?>"><?php echo $URI; ?></a>
							</td>
							<td width="60px" align="center"><a href=""><?php echo round($lv2["avg_stay"], 1); ?> [s]</a></td>
							<td width="60px" align="center"><a href=""><?php echo $lv2["num"]; ?></a></td>
							<td width="53px" align="center"><a href=""><?php echo ($local_sum>0)?round($lv2["num"]/$local_sum*100, 2):"-"; ?> %</a></td>
						</tr><?php
					} ?>
					</table>
				</td>
			</tr> <?php
		}
		else { 
			foreach($lv1 as $URI=>$lv2) { ?>
				<tr style="font-weight:normal;">
					<td colspan="2">
						<img border="0" align="left" id="toggle_img_<?php echo $id; ?>" src="images/empty.png">
						<a href="index.php?page=tracking&report=history&from=<?php echo $get["from"]; ?>&to=<?php echo $get["to"]; ?>&title=<?php echo urlencode($title); ?>"><?php echo $title; ?></a>
					</td>
					<td align="center"><a href=""><?php echo round($lv2["avg_stay"], 1); ?> [s]</a></td>
					<td align="center"><a href=""><?php echo $local_sum; ?></a></td>
					<td align="center"><a href=""><?php echo ($total_sum>0)?round($local_sum/$total_sum*100, 2):"-"; ?> %</a></td>
				</tr> <?php
			}
		}
	} 
	if(!mysql_num_rows($query)) { ?>
		<tr style="font-size: 13px;border-bottom:2px solid #000">
			<td colspan="5"><font color="red">No results</font></td>
		</tr> <?php
	} 
	else { ?>
		<tr style="font-size: 13px;border-bottom:2px solid #000">
			<td colspan="3"></td>
			<td align="center"><?php echo $total_sum; ?></td>
			<td align="center">100%</td>
		</tr><?php
	} ?>
	
