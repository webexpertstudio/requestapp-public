<?php
  //Start session
session_start();
require ("includes/connection.php");  // Poziva kod za konekciju na bazu podataka.
    $agentid = $_SESSION['sess_user_id'];
	$statusdate= date("Y-m-d");
	$idrequest=$_GET['IDrequest'];
	$itinerarysum=str_replace(array('.', ','), array('', '.'), $_POST['itinerarysum']); 
	$itineraryid=$_POST['itineraryid'];
	$statusid=$_POST['statusid'];
/////////////////////////////////////////////NEW ITINERARY
switch ($_GET['change'])
{
	 case "new":
       $itinerarystatus="Quote Sent";
		$newitinerarydata="INSERT INTO itineraries (itinerary_id,request_id,agent_id,itinerary_date,itinerary_status,itinerary_sum,change_date) VALUES ('$itineraryid','$idrequest','$agentid','$statusdate','$itinerarystatus','$itinerarysum','$statusdate')";
		mysql_query($newitinerarydata);
		/////////////////////////////////////////////CHANGE GLOBAL REQUEST STATUS TO "QUOTE SENT"
		$statusfind = mysql_query("SELECT status FROM requests WHERE requestID='$idrequest'");
			while($row = mysql_fetch_assoc($statusfind))
			{
				if ($row['status']=="New" || $row['status']=="Assigned")
				{
					$updatestatus=mysql_query("UPDATE requests SET status='$itinerarystatus', last_change='$statusdate' WHERE requestID='$idrequest'");
					mysql_query($updatestatus);	
					$changes='Request  #'.$idrequest.' change reqeust status to "Quote Sent"';
					$logstats="INSERT INTO log_stats (request_id,agent_id,change_date,change_desc) VALUES ('$idrequest','$agentid','$statusdate','$changes')";
					mysql_query($logstats);
				}
			}
        break;
	 case "update":
       $statusid=$_POST['statusid'];
		$itinerarystatus=$_POST['itinerarystatus'];
			if ($itinerarystatus=="Quote Sent")
			{
			$addstatus=mysql_query("UPDATE itineraries SET itinerary_id='$itineraryid', itinerary_status='$itinerarystatus', itinerary_sum='$itinerarysum', change_date='$statusdate'  WHERE status_id='$statusid'");
			mysql_query($addstatus);
					$changes='Updated itinerary  #'.$itineraryid.' status to '.$itinerarystatus;
					$logstats="INSERT INTO log_stats (request_id,agent_id,change_date,change_desc) VALUES ('$idrequest','$agentid','$statusdate','$changes')";
					mysql_query($logstats);
			}
			else /////////////////////////////////////////////UPDATE BOOKED
			{
			$addstatus=mysql_query("UPDATE itineraries SET itinerary_id='$itineraryid', itinerary_status='$itinerarystatus', itinerary_sum='$itinerarysum', change_date='$statusdate', finalized_date='$statusdate'  WHERE status_id='$statusid'");
			mysql_query($addstatus);	
				if ($itinerarystatus=="Booked") /////////////////////////////////////////////UPDATE GLOBAL REQUEST STATUS
				{

					$updatestatus=mysql_query("UPDATE requests SET finalized_date='$statusdate', status='$itinerarystatus', last_change='$statusdate' WHERE requestID='$idrequest'");
					mysql_query($updatestatus);	
					$changes='Updated itinerary  #'.$itineraryid.' status to '.$itinerarystatus;
					$logstats="INSERT INTO log_stats (request_id,agent_id,change_date,change_desc) VALUES ('$idrequest','$agentid','$statusdate','$changes')";
					mysql_query($logstats);
				}
		}
        break;
   
    case "cancel":
       	$rqstatus="Cancelled";
		$canceltype=$_POST['canceltype'];
			$updatestatus=mysql_query("UPDATE requests SET status='$rqstatus', cancel_type='$canceltype', last_change='$statusdate' WHERE requestID='$idrequest'");
			mysql_query($updatestatus);	
			$changes='Cancelled request #'.$idrequest.', cancellation type: '.$canceltype.' by '.$agentid;
					$logstats="INSERT INTO log_stats (request_id,agent_id,change_date,change_desc) VALUES ('$idrequest','$agentid','$statusdate','$changes')";
					mysql_query($logstats);
        break;
}
if (isset($_GET['tableview']))
{header('Location: index.php?rqopen='.$idrequest.'');}
else
{header('Location: ' . $_SERVER['HTTP_REFERER']);}
exit;
?>
