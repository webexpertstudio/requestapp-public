<?php
  //Start session
session_start();
     require ("includes/connection.php");  // Poziva kod za konekciju na bazu podataka.
$agentid = $_SESSION['sess_user_id'];
$idrequest=$_GET['IDrequest'];
$assignedto=$_GET['agentchange'];
$statusdate= date("Y-m-d");
$status="Assigned";
$agentidfind=mysql_query("SELECT * FROM member WHERE agent_name='$assignedto'");
$agentsdataselected = mysql_fetch_array($agentidfind);
$agentidselected=$agentsdataselected["id"];
$changes='Request  #'.$idrequest.' assigned to '.$assignedto;
$reqstatus = mysql_query("SELECT * FROM requests WHERE requestID='$idrequest'");
while($data = mysql_fetch_assoc($reqstatus))
{
if ($data['status']=="New")
{
	$statuschanging=mysql_query("UPDATE requests SET agentID='$agentidselected', status='$status', last_change='$statusdate' WHERE requestID='$idrequest'");
}
else
{
	$statuschanging=mysql_query("UPDATE requests SET agentID='$agentidselected', last_change='$statusdate' WHERE requestID='$idrequest'");
}
}
mysql_query($statuschanging);
$logstats="INSERT INTO log_stats (request_id,agent_id,change_date,change_desc) VALUES ('$idrequest','$agentid','$statusdate','$changes')";
mysql_query($logstats);


header('Location: ' . $_SERVER['HTTP_REFERER']);
exit;
?>