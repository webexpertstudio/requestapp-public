<?php
	if($_SESSION["sess_agent_status"]!="admin") {
		die("Acces denied");
	}
	// ako je postovano
	$args = array(
		'save' => FILTER_SANITIZE_STRING,
		'delete' => FILTER_SANITIZE_STRING,
		'action' => FILTER_SANITIZE_STRING, 
		'campaign_tid' => FILTER_VALIDATE_INT, 
		'informer_id' => FILTER_VALIDATE_INT, 
		'campaign_name' => FILTER_SANITIZE_STRING,
		'campaign_url' => FILTER_SANITIZE_URL,
		'url_var' => FILTER_SANITIZE_URL,
		'affiliate_id' => FILTER_VALIDATE_INT,
		'campaign_type' => FILTER_SANITIZE_STRING,
		'campaign_name' => FILTER_SANITIZE_STRING,
		
	);
	$post = filter_input_array(INPUT_POST, $args);
	if(isset($post["save"]) && isset($post["action"]) && $post["action"]=="update" && isset($post["campaign_tid"])) {
		$sql = "UPDATE `tbl_campaigns` SET 
					`campaign_tid`='".input_db($post["campaign_tid"])."',
					`informer_id`='".input_db($post["informer_id"])."',
					`affiliate_id`='".input_db($post["affiliate_id"])."',
					`campaign_type`='".input_db($post["campaign_type"])."',
					`campaign_name`='".input_db($post["campaign_name"])."',
					`campaign_url`='".input_db($post["campaign_url"])."',
					`url_var`='".input_db($post["url_var"])."',
					`updated`=NOW() 
			 WHERE campaign_tid='".input_db($post["campaign_tid"])."'";
		exec_query($sql);
		header("Location: index.php?page=campaigns"); 
	}
	if(isset($post["save"]) && isset($post["action"]) && $post["action"]=="insert") {
		$sql = "INSERT INTO `tbl_campaigns` SET 
					`campaign_tid`='".input_db($post["campaign_tid"])."',
					`informer_id`='".input_db($post["informer_id"])."',
					`affiliate_id`='".input_db($post["affiliate_id"])."',
					`campaign_type`='".input_db($post["campaign_type"])."',
					`campaign_name`='".input_db($post["campaign_name"])."',
					`campaign_url`='".input_db($post["campaign_url"])."',
					`url_var`='".input_db($post["url_var"])."',
					`inserted`=NOW() ";
		exec_query($sql);
		header("Location: index.php?page=campaigns"); 
	}
	if(isset($post["delete"]) && isset($post["campaign_tid"])) {
		$sql = "DELETE FROM `tbl_campaigns` c  
				WHERE c.`campaign_tid`='".input_db($post["campaign_tid"])."'
				AND c.`campaign_tid` NOT IN (
					SELECT f.`campaign_tid` 
					FROM `tbl_feedbacks` f
				)";
		exec_query($sql);
		header("Location: index.php?page=campaigns"); 
	}
	
	// get
	$args = array(
		'campaign_tid' => FILTER_VALIDATE_INT, 
		'action' => FILTER_SANITIZE_STRING, 
	);
	$get = filter_input_array(INPUT_GET, $args);
	if(isset($get["action"]) && $get["action"]=="update" && isset($get["campaign_tid"])) {
		$sql = "SELECT *
				FROM `tbl_campaigns` 
				WHERE campaign_tid=".input_db($get["campaign_tid"]);
		$query=db_query($sql);
		$row = mysql_fetch_assoc($query);
	}
	else {
		$row = array();
		$get["action"] = "insert";
	}
	
	$campaign_tid = isset($row["campaign_tid"])?$row["campaign_tid"]:rand (1000000000, 9999999999);
?>
<div id="statusbuttons">
	<button id="tab" onclick="location.href='index.php?page=affiliates'">Affiliates</button>
	<button id="tab" onclick="location.href='index.php?page=informers'">Informers</button>
	<button id="tab" onclick="location.href='index.php?page=campaigns'">Campaigns</button>
	<button id="tab" onclick="location.href='index.php?page=tracking'">Tracking Reports</button>
	<button id="tab" onclick="location.href='index.php?page=campaign&action=insert'">Add new Campaign</button>
</div>
<form method="POST">
	<input type="hidden" name="action" value="<?php echo $get["action"]; ?>">
	<div class="datatable">
		<table width="100%" border="0" cellspacing="0" cellpadding="2" style="font-weight:bold;font-size: 12px;">
			<tr>
				<td width="15%">Campaign Name:</td>
				<td><input type="text" name="campaign_name" style="width:98%" value="<?php echo isset($row["campaign_name"])?$row["campaign_name"]:""; ?>" ></td>
			</tr>
			<tr>
				<td width="15%">Affiliate:</td>
				<td>
					<select name="affiliate_id" ><?php
						$sql = "SELECT * FROM `tbl_affiliates`";
						$query2=db_query($sql);
						while($affiliate = mysql_fetch_assoc($query2)) { ?>
							<option value="<?php echo $affiliate["affiliate_id"] ?>" <?php echo ($row["affiliate_id"]==$affiliate["affiliate_id"])?"selected":"" ?>><?php echo $affiliate["affiliate_name"] ?></option><?php
						} ?>
					</select>
					<a href="index.php?page=affiliate&action=insert">add new</a>
				</td>
			</tr>
			<tr>
				<td width="15%">Campaign Towards (Informer):</td>
				<td>
					<select id="informer_id" name="informer_id" OnChange="var informer=this.options[this.selectedIndex].text; var split = informer.split(' --- '); campaign_url.value=split[1];" ><?php
						$sql = "SELECT * FROM `tbl_informers`";
						$query2=db_query($sql);
						$first_informer_url = "";
						while($informer = mysql_fetch_assoc($query2)) { 
							if(!$first_informer_url) {
								$first_informer_url = $informer["informer_url"];
							} ?>
							<option value="<?php echo $informer["informer_id"] ?>" <?php echo ($row["informer_id"]==$informer["informer_id"])?"selected":"" ?>><?php echo $informer["informer_name"]." --- ".$informer["informer_url"];  ?></option><?php
						} ?>
					</select>
					<a href="index.php?page=informer&action=insert">add new</a>
				</td>
			</tr>
			<tr>
				<td width="15%">Campaign URL:</td>
				<td><?php
					if(isset($row["campaign_url"])) { 
						echo $row["campaign_url"].$row["url_var"].$campaign_tid; ?>
						<a href="javascript:toggleMessage('url');">edit</a>
						<div id="msg_url" class="slideHidden"> <?php
					} ?>
					<input type="text" id="campaign_url" name="campaign_url" style="width:65%" value="<?php echo isset($row["campaign_url"])?$row["campaign_url"]:$first_informer_url; ?>" >
					<select name="url_var" >
						<option value="/?TID=" <?php echo ($row["url_var"]=="/?TID=")?"selected":"" ?>>/?TID=</option>
						<option value="?TID=" <?php echo ($row["url_var"]=="?TID=")?"selected":"" ?>>?TID=</option>
						<option value="&TID=" <?php echo ($row["url_var"]=="&TID=")?"selected":"" ?>>&TID=</option>
					</select>
					<input type="text" name="campaign_tid" style="width:20%" value="<?php echo $campaign_tid; ?>" ><?php
					if(isset($row["campaign_url"])) { ?>
						</div><?php
					} ?> 
				</td>
			</tr>
			<tr>
				<td width="15%">Campaign Type:</td>
				<td>
					<select name="campaign_type" >
						<option value="WEB" <?php echo ($row["campaign_type"]=="WEB")?"selected":"" ?>>WEB</option>
						<option value="BANNER" <?php echo ($row["campaign_type"]=="BANNER")?"selected":"" ?>>BANNER</option>
						<option value="EMAIL" <?php echo ($row["campaign_type"]=="EMAIL")?"selected":"" ?>>EMAIL</option>
					</select>
				</td>
			</tr>
			<tr>
				<td width="15%">Campaign Reports:</td>
				<td>
					<a href="index.php?page=tracking&report=timeline&campaign_tid=<?php echo $campaign_tid; ?>">Visits Timeline</a>
					<a href="index.php?page=tracking&report=per_country&campaign_tid=<?php echo $campaign_tid; ?>">Visits Per Country</button>
					<a href="index.php?page=tracking&report=per_page&campaign_tid=<?php echo $campaign_tid; ?>">Visits Per Page</button>
				</td>
			</tr>
			<tr>
				<td colspan="2" align="center">
					<input type="submit" id="save" name="save" value="Save">
					<input type="submit" id="cancel" name="cancel" value="Cancel" onclick="location.href='index.php?page=campaigns'">
					<input type="submit" id="delete" name="delete" value="Delete" onclick="return confirm('Delete?');">
				</td>
			</tr>
		 </table>
	</div>
</form>
