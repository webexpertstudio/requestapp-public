       </div>
                          </div>
                          <div class="cleared"></div>
                        </div>
                        <div class="cleared"></div>
                      </div>
                    </div>
                    <div class="cleared"></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="cleared"></div>
            <div class="cleared"></div>
          </div>
        </div>
        <div class="art-footer">
          <div class="art-footer-body">
            <div class="art-footer-center">
              <div class="art-footer-wrapper">
                <div class="art-footer-text">
                  <p><a href="http://alpineadventures.net/">HOME</a> | <a href="http://alpineadventures.net/group-trips">GROUPS</a> | <a href="http://www.alpineluxurycollection.com" target="_blank">ALPINELUXURYCOLLECTION.COM</a> | <a href="http://alpineadventures.net/trip-planning-tools">TRIP PLANNING TOOLS</a> | <a href="http://alpineadventures.net/adv/pdf/terms.pdf" target="_blank">TERMS AND CONDITIONS</a> | <a href="http://alpineadventures.net/media-kit">MEDIA KIT</a> | <a href="http://alpineadventures.net/privacy-policy">PRIVACY POLICY</a> | <a href="http://alpineadventures.net/contact-us">CONTACT US</a></p>
                  <p>Copyright 2012 © Alpine Adventures. All rights reserved. | <b>Luxury Ski Vacations</b></p>
                  <p><a href="http://www.skibutlers.com/?pcorpacctid=VGsHDwTE+SE=" target="_blank"><img border="0" height="45" src="images/skibutler.gif" width="53" /></a><img height="45" src="images/traveler.gif" width="53" /><img height="45" src="images/verisign.gif" width="93" /></p> 
                  <div class="cleared"></div>
                  <p class="art-page-footer">Designed by <a href="http://www.alpineadventures.net" target="_blank">Alpine Adventures</a>.</p>
                </div>
              </div>
            </div>
            <div class="cleared"></div>
          </div>
        </div>
        <div class="cleared"></div>
      </div>
    </div>
  </div>
</div>
</body>
</html>