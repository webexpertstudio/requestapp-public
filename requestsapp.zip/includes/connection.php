<?php //Konekcija na bazu podataka.
ini_set('display_errors', '0');
$server="localhost";
$user="alien_requestadm";
$pass="o8^USIm]S05pd@$";
$db="alien_requestapp";

$dbconn=mysql_connect($server, $user, $pass) or die ("Baza nije dostupna!");
mysql_select_db($db) or die ("Baza nije dostupna!");
mysql_select_db('alien_requestapp', $dbconn);
mysql_query("set names 'utf8'",$dbconn);
mysql_query("SET NAMES UTF8");

?>
